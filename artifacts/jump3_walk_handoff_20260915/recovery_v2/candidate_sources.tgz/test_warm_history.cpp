#include "walk_policy.h"
#include <filesystem>
#include <iostream>
void require(bool ok,const char*message){if(!ok)throw std::runtime_error(message);}
int main(int argc,char**argv){
 if(argc!=2)throw std::runtime_error("usage: test_walk_warm_history policy_directory");
 const std::filesystem::path dir=argv[1];auto cfg=YAML::LoadFile(dir/"params/deploy.yaml");
 g1::WalkPolicy policy(cfg);policy.set_history_mode("warm_inference");policy.load((dir/"exported/policy.onnx").string());
 const auto ids=cfg["joint_ids_map"].as<std::vector<int>>();const auto defaults=cfg["default_joint_pos"].as<std::vector<float>>();
 std::vector<g1::ControlFrame> history(4);
 for(int k=0;k<4;++k){auto&f=history[k];f.time=-.08+k*.02;f.angular_velocity=Eigen::Vector3f(.1f,.2f,-.1f);for(int i=0;i<29;++i){f.q[ids[i]]=defaults[i]+.001f*k;f.previous_target[ids[i]]=defaults[i]+.5f;}}
 policy.reset(history);
 const auto actor_previous=policy.env().action_manager->action();
 require(std::any_of(actor_previous.begin(),actor_previous.end(),[](float x){return std::fabs(x)>.01f;}),"warm inference did not build a live actor history");
 auto current=history.back();current.time=0;current.previous_target.fill(5);
 policy.prepare(current,0);
 require(policy.env().action_manager->action()==actor_previous,"last_action overwritten by a foreign/filtered motor target");
 const auto first=policy.step(current,0);
 for(auto&f:history)f.previous_target.fill(-4);
 current.previous_target.fill(-3);
 policy.reset(history);const auto repeated=policy.step(current,0);
 for(int i=0;i<29;++i)require(std::isfinite(first[i])&&std::fabs(first[i]-repeated[i])<1e-6,"warm entry depends on jump motor target or stale prior walk state");
 bool rejected=false;try{policy.set_history_mode("unsupported");}catch(const std::invalid_argument&){rejected=true;}
 require(rejected,"unknown history mode accepted");
 std::cout<<"PASS actual ONNX warm history, own-policy last_action, independence from jump targets and repeated entry\n";
}
