#pragma once

#include "walk_handoff.h"
#include "isaaclab/envs/manager_based_rl_env.h"
#include "isaaclab/envs/mdp/observations/observations.h"
#include "isaaclab/envs/mdp/actions/joint_actions.h"
#include <set>

namespace g1
{
// Private, inference-thread-owned state. It never reads the live DDS message,
// the control thread's joystick, or the motor publisher while constructing obs.
class WalkArticulation : public isaaclab::Articulation
{
public:
    WalkArticulation()
    {
        data.root_quat_w = Eigen::Quaternionf::Identity();
        data.root_ang_vel_b.setZero();
        data.projected_gravity_b = data.GRAVITY_VEC_W;
        data.joystick = &joystick_;
        joystick_.ly.smooth = joystick_.lx.smooth = joystick_.rx.smooth = 1;
        joystick_.ly.deadzone = joystick_.lx.deadzone = joystick_.rx.deadzone = 0;
    }
    void update() override
    {
        // Manager construction resizes q/dq before its first update().
        if (!initialized_) {
            data.joint_pos.setZero();
            data.joint_vel.setZero();
        }
    }

    void set(const ControlFrame& frame, const std::array<float, 3>& command)
    {
        if (!frame.valid()) throw std::invalid_argument("Invalid walk control frame");
        for (int i = 0; i < joint_count; ++i) {
            const int motor = data.joint_ids_map[i];
            data.joint_pos[i] = frame.q[motor];
            data.joint_vel[i] = frame.dq[motor];
        }
        data.root_quat_w = frame.quaternion.normalized();
        data.root_ang_vel_b = frame.angular_velocity;
        data.projected_gravity_b = data.root_quat_w.conjugate() * data.GRAVITY_VEC_W;
        joystick_.ly(command[0]);
        joystick_.lx(-command[1]);
        joystick_.rx(-command[2]);
        initialized_ = true;
    }
private:
    unitree::common::UnitreeJoystick joystick_;
    bool initialized_ = false;
};

class WalkPolicy
{
public:
    explicit WalkPolicy(const YAML::Node& cfg)
    {
        const double period = cfg["step_dt"].as<double>();
        if (!std::isfinite(period) || std::fabs(period - .02) > 1e-6) {
            throw std::invalid_argument("Walk handoff expects the exported 50 Hz policy");
        }
        const auto ids = cfg["joint_ids_map"].as<std::vector<int>>();
        if (ids.size() != joint_count || std::set<int>(ids.begin(), ids.end()).size() != joint_count
            || *std::min_element(ids.begin(), ids.end()) != 0 || *std::max_element(ids.begin(), ids.end()) != 28) {
            throw std::invalid_argument("Walk requires a permutation of 29 G1 motor IDs");
        }
        const auto actions = cfg["actions"];
        if (actions.size() != 1 || !actions["JointPositionAction"]
            || !actions["JointPositionAction"]["joint_ids"].IsNull()) {
            throw std::invalid_argument("Walk requires one full-body JointPositionAction");
        }
        offset_ = actions["JointPositionAction"]["offset"].as<std::vector<float>>();
        scale_ = actions["JointPositionAction"]["scale"].as<std::vector<float>>();
        if (offset_.size() != joint_count || scale_.size() != joint_count) {
            throw std::invalid_argument("Walk action offset/scale dimensions must be 29");
        }
        for (int i = 0; i < joint_count; ++i) {
            if (!std::isfinite(offset_[i]) || !std::isfinite(scale_[i]) || scale_[i] == 0) {
                throw std::invalid_argument("Invalid walk action offset/scale");
            }
        }
        const std::vector<std::string> names = {"base_ang_vel", "projected_gravity", "velocity_commands",
            "joint_pos_rel", "joint_vel_rel", "last_action"};
        if (cfg["observations"].size() != names.size()) throw std::invalid_argument("Unsupported walk observations");
        int k = 0;
        for (const auto& term : cfg["observations"]) {
            if (term.first.as<std::string>() != names[k++] || term.second["history_length"].as<int>() != 5) {
                throw std::invalid_argument("Walk expects the exported six-term, five-frame observation layout");
            }
        }
        robot_ = std::make_shared<WalkArticulation>();
        env_ = std::make_unique<isaaclab::ManagerBasedRLEnv>(cfg, robot_);
        if (robot_->data.joint_stiffness.size() != joint_count || robot_->data.joint_damping.size() != joint_count) {
            throw std::invalid_argument("Walk PD gain dimensions must be 29");
        }
        // Manager construction calls observation terms once; initialize q/dq
        // explicitly before any real inference or history warm-up.
        robot_->set(ControlFrame{}, {});
    }

    void load(const std::string& path) { env_->alg = std::make_unique<isaaclab::OrtRunner>(path); }
    // Configure before entry. Warm inference uses measured history to build
    // the walk actor's own last_action history; these warm-up outputs are never sent.
    void set_history_mode(const std::string& mode)
    {
        if (mode != "applied" && mode != "warm_inference") {
            throw std::invalid_argument("Walk history_mode must be applied or warm_inference");
        }
        applied_feedback_ = mode == "applied";
    }
    void cancel_inference() { if (env_->alg) env_->alg->cancel_inference(); }
    void resume_inference() { if (env_->alg) env_->alg->reset_inference_cancel(); }
    double step_dt() const { return env_->step_dt; }
    const std::vector<float>& stiffness() const { return robot_->data.joint_stiffness; }
    const std::vector<float>& damping() const { return robot_->data.joint_damping; }

    // Supply oldest-to-newest physical samples, excluding the first live step.
    // In warm_inference mode the private actor history contains warm-up outputs;
    // only the caller of the subsequent live step can send a motor target.
    void reset(const std::vector<ControlFrame>& history)
    {
        if (history.empty()) throw std::invalid_argument("Walk history is empty");
        env_->reset();
        if (!applied_feedback_) {
            if (!env_->alg) throw std::runtime_error("Warm walk history requires a loaded policy");
            prepare(history.front(), 0);
            env_->observation_manager->reset();
            for (size_t i = 1; i < history.size(); ++i) step(history[i], 0);
            return;
        }
        for (size_t i = 0; i < history.size(); ++i) {
            prepare(history[i], 0);
            if (i == 0) env_->observation_manager->reset();
            else env_->observation_manager->compute();
        }
    }

    JointVector step(const ControlFrame& frame, float command_gain)
    {
        if (!env_->alg) throw std::runtime_error("Walk policy not loaded");
        prepare(frame, command_gain);
        env_->step();
        const auto target = env_->action_manager->processed_actions();
        JointVector motor_target{};
        for (int i = 0; i < joint_count; ++i) {
            if (!std::isfinite(target[i])) throw std::runtime_error("Non-finite walk policy output");
            motor_target[static_cast<int>(robot_->data.joint_ids_map[i])] = target[i];
        }
        return motor_target;
    }

    // Same path as step(), exposed to offline observation parity tests.
    void prepare(const ControlFrame& frame, float command_gain)
    {
        const auto ranges = env_->cfg["commands"]["base_velocity"]["ranges"];
        const char* keys[] = {"lin_vel_x", "lin_vel_y", "ang_vel_z"};
        std::array<float, 3> command{};
        for (int j = 0; j < 3; ++j) {
            command[j] = std::clamp(frame.command[j], ranges[keys[j]][0].as<float>(),
                                   ranges[keys[j]][1].as<float>()) * std::clamp(command_gain, 0.0f, 1.0f);
        }
        robot_->set(frame, command);
        std::vector<float> previous(joint_count);
        for (int i = 0; i < joint_count; ++i) {
            previous[i] = (frame.previous_target[static_cast<int>(robot_->data.joint_ids_map[i])] - offset_[i]) / scale_[i];
        }
        // Legacy mode encodes sent targets. Warm-inference mode retains the
        // actor's previous clipped output, matching the policy last_action term.
        if (applied_feedback_) env_->action_manager->process_action(previous);
    }

    isaaclab::ManagerBasedRLEnv& env() { return *env_; }

private:
    bool applied_feedback_ = true;
    std::shared_ptr<WalkArticulation> robot_;
    std::unique_ptr<isaaclab::ManagerBasedRLEnv> env_;
    std::vector<float> offset_, scale_;
};
}  // namespace g1
