#include "walk_policy.h"
#include <mujoco/mujoco.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>

struct Csv {
 std::map<std::string,int> columns; std::vector<std::vector<double>> rows;
 explicit Csv(const char* path) {
  std::ifstream f(path);if(!f)throw std::runtime_error("Cannot read source rollout");
  std::string line,x;std::getline(f,line);std::stringstream h(line);int c=0;while(std::getline(h,x,','))columns[x]=c++;
  while(std::getline(f,line)){std::stringstream s(line);std::vector<double> row;while(std::getline(s,x,','))row.push_back(std::stod(x));rows.push_back(row);}
 }
 double at(int r,const std::string& c)const{return rows.at(r).at(columns.at(c));}
};
int main(int argc,char**argv) {
 if(argc<5) {std::cerr<<"replay scene source.csv summary.csv rollout_prefix\n";return 2;}
 Csv source(argv[2]);int sw=-1;
 for(int i=1;i<int(source.rows.size());++i)if(source.at(i-1,"state")==112&&source.at(i,"state")==3){sw=i;break;}
 if(sw<80)throw std::runtime_error("No complete pre-handoff history");
 char error[2048];mjModel*m=mj_loadXML(argv[1],nullptr,error,sizeof(error));if(!m)throw std::runtime_error(error);m->opt.timestep=.001;
 mjData*d=mj_makeData(m);int qa[29],va[29];for(int i=0;i<29;++i){int j=m->actuator_trnid[2*i];qa[i]=m->jnt_qposadr[j];va[i]=m->jnt_dofadr[j];}
 int iq=m->sensor_adr[mj_name2id(m,mjOBJ_SENSOR,"imu_quat")],ig=m->sensor_adr[mj_name2id(m,mjOBJ_SENSOR,"imu_gyro")];
 auto cfg=YAML::LoadFile("/home/ustczxh/humanoid/zxh-isaaclab/deploy/robots/g1_29dof/config/policy/velocity/params/deploy.yaml");
 g1::WalkPolicy policy(cfg);policy.load("/home/ustczxh/humanoid/zxh-isaaclab/deploy/robots/g1_29dof/config/policy/velocity/exported/policy.onnx");
 auto restore=[&](int row){for(int j=0;j<m->nq;++j)d->qpos[j]=source.at(row,"qpos"+std::to_string(j));for(int j=0;j<m->nv;++j)d->qvel[j]=source.at(row,"qvel"+std::to_string(j));mj_forward(m,d);};
 g1::JointVector applied{};
 auto frame=[&](double t){g1::ControlFrame f;f.time=t;f.previous_target=applied;for(int j=0;j<29;++j){f.q[j]=d->qpos[qa[j]];f.dq[j]=d->qvel[va[j]];}f.quaternion=Eigen::Quaternionf(d->sensordata[iq],d->sensordata[iq+1],d->sensordata[iq+2],d->sensordata[iq+3]);for(int j=0;j<3;++j)f.angular_velocity[j]=d->sensordata[ig+j];return f;};
 std::vector<g1::ControlFrame> history;
 for(int k=4;k>0;--k){int row=sw-20*k;restore(row);for(int j=0;j<29;++j)applied[j]=source.at(row-1,"target"+std::to_string(j));history.push_back(frame(-.02*k));}
 struct Profile{const char*name;double blend,rate;};
 const std::vector<Profile> profiles={{"legacy",.30,0},{"recovery",.08,30}};
 std::ofstream summary(argv[3]);summary<<"profile,scenario,failed,failure_t,min_z,max_tilt,final_z,final_tilt,max_target_step_first_s\n";
 for(const auto&profile:profiles)for(int scenario=0;scenario<5;++scenario){
  mj_resetData(m,d);restore(sw);
  if(scenario){d->qvel[3]=scenario==2?1.867:(scenario==3?-2.5:-1.867);d->qvel[4]=.833;d->qvel[5]=.793;mj_forward(m,d);}
  if(scenario==4){d->qpos[qa[14]]=.305;mj_forward(m,d);}
  for(int j=0;j<29;++j)applied[j]=source.at(sw,"target"+std::to_string(j));
  if(scenario==4)applied[14]=-.520f;  // Additional synthetic waist tracking error from the real log.
  const std::string pname=profile.name;
  policy.set_history_mode(pname=="legacy"?"applied":"warm_inference");
  policy.reset(history);
  g1::WalkEntryConfig entry;entry.blend_time=profile.blend;entry.max_target_rate=profile.rate;entry.require_stability=true;
  g1::WalkHandoff handoff(entry);handoff.begin(applied,0);g1::JointVector pending{},candidate=applied;bool pending_ready=false,failed=false;double fail_t=-1,minz=10,maxtilt=0,maxstep=0,lasttilt=0;
  std::string name=std::string(argv[4])+"_"+profile.name+"_"+std::to_string(scenario)+".csv";
  std::ofstream trace(name);trace<<std::setprecision(9)<<"time,z,tilt,command_gain,waist_q,waist_applied,waist_candidate";for(int j=0;j<m->nq;++j)trace<<",qpos"<<j;trace<<'\n';
  for(int tick=0;tick<4000;++tick){
   mj_forward(m,d);
   double t=tick*.001;auto f=frame(t);handoff.observe_stability(f,t);
   if(pending_ready){candidate=pending;handoff.publish(candidate,t);pending_ready=false;}
   if(tick%20==0){pending=policy.step(f,handoff.command_gain(t));pending_ready=true;}
   const auto next=handoff.sample(t);if(t<1)for(int j=0;j<29;++j)maxstep=std::max(maxstep,double(std::fabs(next[j]-applied[j])));applied=next;
   for(int j=0;j<29;++j)d->ctrl[j]=policy.stiffness()[j]*(applied[j]-d->qpos[qa[j]])-policy.damping()[j]*d->qvel[va[j]];
   lasttilt=std::acos(std::clamp(1-2*(d->qpos[4]*d->qpos[4]+d->qpos[5]*d->qpos[5]),-1.,1.));minz=std::min(minz,d->qpos[2]);maxtilt=std::max(maxtilt,lasttilt);
   if(tick%5==0){trace<<t<<','<<d->qpos[2]<<','<<lasttilt<<','<<handoff.command_gain(t)<<','<<d->qpos[qa[14]]<<','<<applied[14]<<','<<candidate[14];for(int j=0;j<m->nq;++j)trace<<','<<d->qpos[j];trace<<'\n';}
   if(lasttilt>1||d->qpos[2]<.4||handoff.fault(t)){failed=true;fail_t=t;break;}
   mj_step(m,d);
  }
  summary<<profile.name<<','<<scenario<<','<<failed<<','<<fail_t<<','<<minz<<','<<maxtilt<<','<<d->qpos[2]<<','<<lasttilt<<','<<maxstep<<'\n';summary.flush();
  std::cout<<profile.name<<" scenario="<<scenario<<" failed="<<failed<<" t="<<fail_t<<" min_z="<<minz<<" tilt="<<maxtilt<<" maxstep="<<maxstep<<std::endl;
 }
 mj_deleteData(d);mj_deleteModel(m);
}
