#include "walk_handoff.h"
#include <iostream>
void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
int main(){
 g1::WalkEntryConfig cfg;cfg.blend_time=.08;cfg.max_target_rate=10;cfg.require_stability=true;
 g1::WalkHandoff h(cfg);g1::JointVector seed{},target{};seed.fill(.2);target.fill(-1.5);
 h.begin(seed,0);h.publish(target,.05);check(h.sample(.05)==seed,"first applied target must match previous sent target");
 auto previous=seed;g1::ControlFrame f;f.quaternion=Eigen::Quaternionf(Eigen::AngleAxisf(.6f,Eigen::Vector3f::UnitY()));
 double peak=0;
 for(int i=1;i<=2000;++i){
  double t=.05+i*.001;
  if(i%20==0){target.fill(i<900?(i%40==0?1.5f:-1.5f):.7f);h.publish(target,t);}
  f.time=t;if(i==1000)f.quaternion=Eigen::Quaternionf::Identity();
  h.observe_stability(f,t);auto q=h.sample(t);
  if(i<=1000){for(int j=0;j<29;++j){peak=std::max(peak,double(std::fabs(q[j]-previous[j])));check(std::fabs(q[j]-previous[j])<=.010001,"target changed faster than 10 rad/s during entry");}}
  if(i<1200)check(h.command_gain(t)==0,"command released before continuous stability hold");
  if(i==1100)check(h.snapshot(t).limiting,"limiter released before the entry stability gate");
  previous=q;
 }
 check(h.command_gain(2.05)>.999,"command did not return after sustained stability and ramp");
 check(std::fabs(previous[0]-.7f)<1e-5,"limiter did not catch up to live target");
 h.begin(seed,3);check(h.sample(3)==seed&&h.command_gain(3)==0,"entry state not reset");
 h.publish(target,3.01);h.sample(3.01);auto late=h.sample(3.11);
 check(std::fabs(late[0]-seed[0])<=.010001,"late main loop created a catch-up jump");
 check(h.fault(3.22),"watchdog lost");
 std::cout<<"PASS recovery slew bound, changing live candidates, stability gate, catch-up, re-entry and watchdog; max step="<<peak<<'\n';
}
