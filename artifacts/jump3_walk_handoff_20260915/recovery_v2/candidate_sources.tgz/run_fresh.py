from pathlib import Path
import subprocess,json
import numpy as np
root=Path(__file__).parent
def run(args,log):
 with (root/log).open('w') as f:
  r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(log)
results=[]
for plant in ['sdk','matched']:
 scene=f'/tmp/g1_jump_walk_sim_20260915/scene_{plant}.xml'
 name=f'fresh_{plant}_baseline'
 run([str(root/'build/sim'),scene,str(root/f'{name}.csv'),'sequence','.30','7','0','0','legacy','nominal'],f'{name}.log')
 run([str(root/'build/replay'),scene,str(root/f'{name}.csv'),str(root/f'fresh_paired_{plant}.csv'),str(root/f'fresh_paired_{plant}')],f'fresh_paired_{plant}.log')
 for scenario in ['nominal','real_gyro','mirrored_gyro','strong_roll','waist_error']:
  name=f'fresh_{plant}_{scenario}_recovery'
  run([str(root/'build/sim'),scene,str(root/f'{name}.csv'),'sequence','.08','7','0','0','recovery',scenario],f'{name}.log')
  a=np.genfromtxt(root/f'{name}.csv',delimiter=',',names=True)
  idx=np.where((a['state'][1:]==3)&(a['state'][:-1]==112))[0]+1
  row=dict(case=name,switched=bool(len(idx)),passive=bool(np.any(a['state']==1)))
  if len(idx):
   b=a[idx[0]:];q=np.column_stack([b[f'target{i}'] for i in range(29)]);w=b['time']<b['time'][0]+1
   row.update(min_z=float(b['z'].min()),max_tilt=float(np.degrees(b['pelvis_tilt'].max())),final_z=float(b['z'][-1]),final_tilt=float(np.degrees(b['pelvis_tilt'][-1])),first_s_max_target_step=float(abs(np.diff(q[w],axis=0)).max()))
  results.append(row);(root/'fresh_threaded.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
